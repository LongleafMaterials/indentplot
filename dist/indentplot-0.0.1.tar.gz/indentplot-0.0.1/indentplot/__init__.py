# -*- coding: utf-8 -*-
"""
Created on Sun Nov 17 10:10:44 2024

@author: Fletcher
"""

from parse import brukerTDM

